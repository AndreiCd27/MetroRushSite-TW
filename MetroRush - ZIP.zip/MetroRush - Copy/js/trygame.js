
var stationData = [
    [96,146,"Straulesti"],
    [129,192,"Laminorului"],
    [156,226,"Parc Bazilescu"],
    [175,251,"Jiului"], 
    [228,309,"1 Mai"],
    [263,362,"Grivita"],
    [314,409,"Basarab"],
    [348,432,"Gara de Nord"],
    [398,402,"Piata Victoriei"],
    [494,396,"Stefan cel Mare"],
    [594,416,"Obor"],
    [638,457,"Piata Iancului"],
    [661,503,"Piata Muncii"],
    [665,549,"Dristor 2"],
    [655,567,"Dristor 1"],
    [781,595,"Nicolae Grigorescu"],
    [785,538,"Titan"],
    [816,480,"Costin Georgian"],
    [902,494,"Republica"],
    [933,459,"Pantelimon"],
    [835,606,"1 Decembrie 1918"],
    [935,624,"Nicolae Teclu"],
    [595,604,"Mihai Bravu"],
    [537,577,"Timpuri Noi"],
    [482,527,"Piata Unirii"],
    [421,496,"Izvor"],
    [343,485,"Eroilor"],
    [271,447,"Grozavesti"],
    [206,429,"Petrache Poenaru"],
    [209,398,"Crangasi"],
    [240,490,"Politehnica"],
    [137,491,"Lujerului"],
    [68,492,"Gorjului"],
    [11,493,"Pacii"],
    [551,259,"Pipera"],
    [467,266,"Aurel Vlaicu"],
    [403,333,"Aviatorilor"],
    [457,434,"Piata Romana"],
    [482,486,"Universitate"],
    [493,591,"Tineretului"],
    [454,642,"Eroii Revolutiei"],
    [512,671,"Constantin Brancoveanu"],
    [586,701,"Piata Sudului"],
    [647,768,"Aparatorii Patriei"],
    [683,811,"Dimitrie Leonida"],
    [727,871,"Berceni"],
    [770,930,"Tudor Arghezi"],
    [287,515,"Academia Militara"],
    [244,532,"Orizont"],
    [205,541,"Favorit"],
    [171,547,"Tudor Vladimirescu"],
    [135,552,"Parc Drumul Taberei"],
    [97,545,"Romancierilor"],
    [69,559,"Constantin Brancusi"],
    [90,580,"Raul Doamnei"],
    [36,558,"Valea Ialomitei"]
]

var Canvas
var ctx

var passengersPerDay = 0
var totalPassengers = 0

function randC() {
    const r = parseInt(Math.floor(Math.random()*256)) +50
    if (r>255) {
        return 255
    }
    return r
}

function getRandColor() {
    const randColor = "rgba("+(randC())+", "+(randC())+", "+(randC())+", 1)"
    return randColor
}

function LineObject(colorKey,color) {
    this.Key = colorKey
    this.List = []
    this.Color = color
}

function GraphObject() {
    this.Lines = {}
    this.NrOfLines = 0
    this.addHTML_Elements = function(colorKey,color) {
        const clone = document.getElementById("temp").cloneNode()
        clone.style.color = color
        clone.style.borderColor = color
        clone.style.display = "block"
        clone.innerHTML = "MetroLine " + this.NrOfLines
        clone.id = colorKey
        clone.tag = "instance"
        document.getElementById("trackUI").appendChild(clone)
    }
    this.createLine = function(colorKey,color,st0,st1) {
        this.NrOfLines += 1
        this.Lines[colorKey] = new LineObject(colorKey)
        let LineObj = this.Lines[colorKey]
        LineObj.Color = color
        LineObj.List.push(st0.ID)
        LineObj.List.push(st1.ID)
        this.addHTML_Elements(colorKey,color)
        passengersPerDay += st0.Popularity
        passengersPerDay += st1.Popularity
    }
    this.checkNoIntersections
    this.addStationToLine = function(stTarget,stOrigin,colorKey) {
        let LineObj = this.Lines[colorKey]
        if (stOrigin.ID == LineObj.List[LineObj.List.length-1]) {
            LineObj.List.push(stTarget.ID)
            passengersPerDay += stTarget.Popularity
            return true
        }
        if (stOrigin.ID == LineObj.List[0]) {
            LineObj.List.splice(0,0,stTarget.ID)
            passengersPerDay += stTarget.Popularity
            return true
        }
        console.log("LINE LIST INSSERTIOn Failed")
        return false
    }
}

var ST = []

function StationObject(id,x,y,map,stationName) {
    this.ID = id
    this.Position = {X: x, Y: y}
    this.MapID = map.ID
    this.StationTag = stationName
    this.Popularity = parseInt(Math.floor(Math.random()*10))
    this.ColorRGB = "rgba(187, 255, 0, 1)"
    this.ColorDefault = true
    this.StationElem = null
    this.connectTo = function(stationObject) {
        console.log("Connecting to ... " + stationObject.StationTag)
    }
    this.getGroupColor = function() {
        let minDist = 999999
        let minObjColor = "rgba(187, 255, 0, 1)"
        map.ClutterStations.forEach(stObjX => {
            const d = (stObjX.Position.X-x)**2 + (stObjX.Position.Y-y)**2
            if (minDist > d ) {
                minDist = d
                minObjColor = stObjX.ColorRGB
            }
        });
        this.ColorRGB = minObjColor
    }
    this.instanceStation = function(left,top) {
        const station = document.createElement("div")
        station.tagName = stationName
        station.id = id
        station.style.backgroundColor = "rgba(187, 255, 0, 1)"
        station.style.borderRadius = "30%"
        station.style.height = "10px"
        station.style.width = "10px"
        station.style.left = left+"px"
        station.style.top = top+"px"
        station.style.borderStyle = "solid"
        station.style.borderColor = "rgba(48, 48, 48, 1)"
        station.style.borderWidth = "1px"
        station.style.position = "absolute"
        station.style.zIndex = 15
        station.style.alignSelf = "center"
        if(true) {
            station.style.backgroundColor = this.ColorRGB
        }
        mapContainer.appendChild(station)
        this.StationElem = station
        ST.push(station)
        station.onclick = function() {
            console.log("station CLICK (ID="+id+")")
            if (select0 != null) {
                select1 = id
                //create edge
                //createEdge()
                map.connectStations(parseInt(select0),parseInt(select1))
                select0 = null
                select1 = null
            } else {
                select0 = id
            }
        }
    }
}

function mapObject(mapID,mapPathName) {
    this.Graph = new GraphObject()
    this.ID = mapID
    this.localTime = new Date()
    this.Tiles = []
    this.Stations = []
    this.ClutterStations = []
    this.passengers = totalPassengers
    this.TILES_PATH = "maps/"+mapPathName+"/TILES/output_" //default
    this.IMG_extension = '.png' //default
    this.loadTiles = function() {
        for (let i = 1; i <= 5; i++) {
            this.Tiles[i] = []
            for (let j = 0; j <= 4; j++) {
                const tileMap = document.createElement("div")
                tileMap.style.backgroundImage = "url('" + this.TILES_PATH + (i+j*5) + 
                    this.IMG_extension + "')"
                mapContainer.appendChild(tileMap)
                this.Tiles[i][j] = tileMap
            }
        }
    }
    this.unloadTiles = function() {
        for (let i = 1; i <= 5; i++) {
            for (let j = 0; j <= 4; j++) {
                this.Tiles[i][j].remove()
                this.Tiles[i][j] = null
            }
        }
    }
    this.loadStationValues = function() {
        let id = 0
        stationData.forEach(table => {
            let x = table[0]
            let y = table[1]
            let StationObj = new StationObject(id,x,y,this,table[2])
            this.Stations[id] = StationObj
            id += 1
        });
    }
    this.selectRandomClutterStations = function() {
        const clutter_st_nr = 6
        for (let iter = 0; iter < clutter_st_nr; iter++) {
            const index = parseInt(Math.floor(Math.random()*this.Stations.length))
            const stationObj = this.Stations[index]
            this.ClutterStations.push(stationObj)
            stationObj.ColorRGB = getRandColor()
            stationObj.ColorDefault = false
            stationObj.Popularity *= 2
        }
    }
    this.loadStationInstances = function() {
        this.Stations.forEach(StationObj => {
            if (StationObj.ColorDefault) {
                StationObj.getGroupColor()
            }
            StationObj.instanceStation(StationObj.Position.X,StationObj.Position.Y)
        })
    }
    this.unloadStations = function() {
        ST.forEach(station => {
                if(station!=null) {
                    station.remove()
                }
        });
        this.Stations = []
        this.ClutterStations = []
        this.Graph.Lines = {}
        ST = []
        document.getElementById("trackUI").childNodes.forEach(element => {
            if(element.tagName == "instance") {
                element.remove()
            }
        });
    }
    this.drawLine = function(st0,st1,clr_new) {
        console.log("Connecting "+st0.StationTag+" to "+st1.StationTag)
        let clr = document.getElementById("colorBox").value
        if (clr_new) {
            clr = clr_new
        }
        ctx.beginPath()
        ctx.moveTo(st0.Position.X+5, st0.Position.Y+5)
        console.log("Move to "+st0.Position.X+", "+st0.Position.Y)
        ctx.lineTo(st1.Position.X+5, st1.Position.Y+5)
        console.log("Move to "+st1.Position.X+", "+st1.Position.Y)
        ctx.closePath()
        ctx.strokeStyle = clr
        ctx.lineWidth = 5
        ctx.stroke()
    }
    this.connectStations = function(sel0,sel1,clrKey,newClr) {
        //sel0, sel1 -> selectori (id-uri) statii
        st0 = this.Stations[sel0]
        st1 = this.Stations[sel1]
        let clr = document.getElementById("colorBox").value
        if (newClr) {
            clr = newClr
        }
        
        let clrKeyGlobalClone = clrKeyGlobal
        if (clrKey) {
            clrKeyGlobalClone = clrKey
        }
        if (this.Graph.Lines[clrKeyGlobalClone]) {
            const success = this.Graph.addStationToLine(st1,st0,clrKeyGlobalClone)
            if(success) {
                this.drawLine(st0,st1,clr)
            } else {
                console.log("Could not add station to line")
            }
        } else {
            this.Graph.createLine(clrKeyGlobalClone,clr,st0,st1)
            this.drawLine(st0,st1,clr)
        }
    }
}

var mapContainer

function changeMargin(values, valueI, add) {
    let marginValue = ""
    for (let i = 0; i < 4; i++) {
        if (valueI == i) {
            marginValue = marginValue + (parseInt(values[i])+add) + "px "
        } else {
            marginValue = marginValue + (parseInt(values[i])) + "px "
        }
    }
    return marginValue;
}

function pressedKey(event) {
    if (!active) {
        return
    }
    let values = (mapContainer.style.margin).split("px ");
    let keys = ["a","d","s","w"];
    let posChange = [10,-10,-10,10];
    for (let i = 0; i < 4; i++) {
        if(event.key == keys[i] ) {
            let valueI = 3; if (i > 1) {valueI=0;};
            let marginValue = changeMargin(values, valueI, posChange[i] );
            console.log(marginValue);
            mapContainer.style.margin = marginValue;
        }
    }
    let SCALE = mapContainer.style.scale;
    if (event.key == "+") {
        console.log(parseFloat(SCALE)+0.2);
         mapContainer.style.scale = parseFloat(SCALE)+0.2;
    }
     if (event.key == "-") {
        console.log(parseFloat(SCALE)-0.2);
         mapContainer.style.scale = parseFloat(SCALE)-0.2;
    }
}

var select0 = null
var select1 = null

var active = true
var loaded = true

function deactivateMap() {
    mapContainer.parentElement.parentElement.style.display = "none"
    active = false
}

function activateMap() {
    mapContainer.parentElement.parentElement.style.display = "block"
    active = true
}

var NewMap

function unloadMap() {
    if (loaded == true) {
        NewMap.unloadTiles()
        NewMap.unloadStations()
        ctx.clearRect(0, 0, Canvas.width, Canvas.height);
        loaded = false
        document.getElementById("unloadMap").innerHTML = "LOAD MAP"
    } else {
        //prompt cu hartile saved
        loadPromt = document.getElementById("LoadFromPrevious")
        loadPromt.style.display = "flex"
        for (const entryLoad of loadPromt.childNodes) {
            if (entryLoad.id!="new") {
                entryLoad.remove()
            }
        }
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i)
            let entryLoad = loadPromt.querySelector("#new").cloneNode()
            loadPromt.appendChild(entryLoad)
            entryLoad.innerHTML = key
            entryLoad.id = key
            entryLoad.onclick = function() {
                loadPromt.style.display = "none"
                alert("Loading "+key+" ...")
                loadFromPrevious(key)
            }
        }
    }
}

function loadFromPrevious(mapname) {
    const jsonString = window.localStorage.getItem(mapname)
    const data = JSON.parse(jsonString)
    console.log(jsonString)
    NewMap = new mapObject(1,"bucharest")
    NewMap.localTime = data.localTime
    totalPassengers = data.passengers
    console.log(data)
    NewMap.loadTiles()
    NewMap.loadStationValues()
    NewMap.selectRandomClutterStations()
    NewMap.loadStationInstances()
    loaded = true
    document.getElementById("unloadMap").innerHTML = "UNLOAD MAP"
    let LINES = data.Graph.Lines
    for (lineKey in LINES) {
        let sel0 = null
        let sel1 = null
        for (let i = 0; i < LINES[lineKey].List.length; i++) {
            sel1 = LINES[lineKey].List[i]
            if(i>0) {
                NewMap.connectStations(sel0,sel1,lineKey,LINES[lineKey].Color)
            }
            sel0 = sel1
        }
    }
}

function saveMapObject() {
    mapname=prompt("Enter map name: ")
    window.localStorage.setItem(mapname,JSON.stringify(NewMap))
}

var clrKeyGlobal = 0

window.addEventListener("DOMContentLoaded",function () {
    Canvas = document.getElementById("Canvas")
    ctx = Canvas.getContext("2d")

    mapContainer = document.body.querySelector("#mapTiles")
    mapContainer.style.margin = "-255px 0px 0px -55px";
    mapContainer.style.scale = 1;

    const cliWidth = mapContainer.clientWidth
    const cliHeight = mapContainer.clientHeight
    console.log(cliWidth,cliHeight)
    Canvas.style.width = cliWidth+"px"
    Canvas.style.height = cliHeight+"px"

    NewMap = new mapObject(1,"bucharest")
    NewMap.loadTiles()
    NewMap.loadStationValues()
    NewMap.selectRandomClutterStations()
    NewMap.loadStationInstances()

    const clrBox = document.getElementById("colorBox")
    clrBox.addEventListener("change",function(){
        clrKeyGlobal = clrBox.value
        console.log(clrKeyGlobal)
    })

    window.onkeydown = pressedKey;

    deactivateMap()

    loadPromt = document.getElementById("LoadFromPrevious")
    loadPromt.querySelector("#new").onclick = function() {
        loaded = false
        NewMap = new mapObject(1,"bucharest")
        NewMap.loadTiles()
        NewMap.loadStationValues()
        NewMap.selectRandomClutterStations()
        NewMap.loadStationInstances()
        loaded =true
        document.getElementById("unloadMap").innerHTML = "UNLOAD MAP"
        loadPromt.style.display = "none"
    }

    const passengerText = document.getElementById("passengersText")
    const passengersPerDayText = this.document.getElementById("passengersPerDayText")
    setInterval(function() {
        totalPassengers += passengersPerDay
        passengerText.innerHTML = "Passengers transported: "+totalPassengers
        passengersPerDayText.innerHTML = "+"+passengersPerDay+"/sec"
        NewMap.passengers = totalPassengers
    },5000)

    //mapContainer.addEventListener("click",printMousePos)
})