dict = {
    "A": ["ABOUT THE GAME", 
        "Metro Rush is nothing more than a Metro Tycoon. You plan out train lines, take some passengers on their way to work and earn money to expand your metro buisness. Connect your first stations and plan your next moves strategically. <br><br> !!! BUT BE CAUTIOUS: Other people want to expand their metro networks as well. They're not afraid of sending mechanical-destruction-machines your way!<br><br> So defend your trains & rails, compete for dominance and expand your metro empire!<br><br>",
        "FEATURES (as of 14/11/2025) <br><br> > Build your own metro rails <br> > Create your own lines by connecting stations <br> > Assign trains to metro lines to manage passenger flow <br> > Transport passengers through your metro network <br> > Interact with other users creating a metro network on the same map <br> > Send battle-trains to secure your network and destroy the enemy's capacity to expand <br> > Customize metro lines <br> > Navigate the 2D Map of your metro lines <br> > Travel to any station<br> > Recieve information about where passengers are going to <br> > Create your metro lines according to passenger flow <br> > Choose between 2 Maps to play on" 
    ],
    "B": ["DEVELOPMENT UPDATES",
        "Metro Rush is now at an early stage in development. Please beware of some things not working as expected. I am working on fixing any bugs encountered and making the game more performant. I am currently adding more features to match with my game ideas. Any suggestions are always welcomed!",
        "Update 11/11/2025 > UI Color Pallete changed "
    ],
    "C": ["MAPS & TRAINS",
        "Available trains: ",
        "Available maps: "
    ],
    "D": ["GAME NEWS","Announcement (16/11/2025) <br><br> This game will soon go public for everyone to test and play. Essential features are 90% done. Some work must be done before this game can offer a good user-experience. <br><br> I am also working on improving performance issues. At the moment the game can't handle a huge ammount of trains due to some inefficient code. <br><br> At first, the game will not be available to play on mobile.",""],
    "E": ["GAME NEWS","Announcement (16/11/2025) <br><br> This game will soon go public for everyone to test and play. Essential features are 90% done. Some work must be done before this game can offer a good user-experience. <br><br> I am also working on improving performance issues. At the moment the game can't handle a huge ammount of trains due to some inefficient code. <br><br> At first, the game will not be available to play on mobile.",""],
    "F": ["HOW TO PLAY"," The best way to learn the game is by playing the game, but here are some general tutorials: <br> <br>","<h2>Strategies</h2> <br><br> I) To earn the most ammount of money, you need to transport as many passengers as possible. You get a tiny ammount of money for each passenger that enters or leaves one of your trains. <br><br> II) Some stations are more popular than others, so make sure to secure them fast. More passengers will spawn there. <br><br> III) Make sure to create your metro lines according to passenger flow. Any station has multiple groups of people going to different destinations. The chance for a group of people to select a certain destination grows based on proximity and station popularity. <br><br>"],
    "G": ["ABOUT ROBLOX","Roblox is an online platform where users can play and create games, customize their avatars and join public/private servers in millions of games. <br><br> Roblox handles server-traffic, transactions and moderation to make their platform as user-friendly as possible. It has grown huge over the years, at any given moment having an average of 20-30 million active users. <br><br> On the developer side of things, now there is more demand for creativity for your game to stand out. Some truly amazing games reside here on Roblox, even though they may be hard to find nowadays. <br> (today many developers want to make an engaging game that gets popular quick) <br><br> In my opinion, old Roblox was better, simpler, and more fun. But maybe that's just nostalgia. I don't play Roblox anymore, I just work on my games in my free time. <br> _________","MAKING GAMES ON ROBLOX  <br><br> To make a game in Roblox, you first need to be familiar with it's game-engine: Roblox-Studio.<br><br> Similar to Unity, it handles 3D object instances, Physics, Lighting, User-Interface and more. <br><br>Since on Roblox every game is multiplayer*, every project must have both server-side AND client-side scripts. Communication between the server-side and client-side can be done through so-called 'Events'.<br><br> The programming language used in this game-engine is Lua, in some ways similar to JavaScript or Python. <br><br> <i> 'Lua and Python are both interpreted, dynamically typed, garbage-collected programming languages that are implemented in, and can be extended in, C. Both support procedural, object-oriented, and functional programming.'</i> <a target = '_blank' href='https://www.linode.com/docs/guides/lua-vs-python/'> (source) </a> <br>"],
    "H": ["ABOUT ME",
        " Hello to anyone reading this! I am Andrei, a small game developer & computer science student <br><br> My experience as a programmer: <br> > I have been improving my game-developing skills here on Roblox; 5 years of experience coding on Roblox Studio <br> (I have another project you can check out - Tram Traffic Bucharest) <br> > I am experienced in C++, Python, Lua <br> > I have some basic skills in Web Development <br><br> I go by my username: AndreiCd27 <br><br> <a target='_blank' href='https://www.roblox.com/users/716569060/profile/'> Roblox profile </a>",
        "<br> My old side project: <br><br> <a target='_blank' href='https://www.roblox.com/games/14605138482/Tram-Traffic-Bucharest'> Tram Traffic Bucharest</a><br><br>"
    ],
};

function CreateImageString(source,aspectRatio) {
    let str = "<br> <img src='" + source + "' style='width: 80%; aspect-ratio: " + aspectRatio + "; border-style: solid; border-color: rgb(0,255,0); border-width: 2px; margin: 5px; image-resolution: 600dpi;'>";
    return str;
}

function CreateVideoString(source,aspectRatio) {
    let str = "<video style='width: 80%; aspect-ratio: " + aspectRatio + "; border-style: solid; border-color: rgb(0,255,0); border-width: 2px; margin: 5px;' controls> <source src='" + source + "' type='video/mp4'> </video>"
    return str;
}

//CONCATENAM CU IMAGINILE PT SECTIUNEA "B" (DEV UPDATES)
dict.B[2] = dict.B[2] + CreateImageString("imgs/NewUI.png","2/1");
dict.B[2] = dict.B[2] + "<br> > New black and green UI-design! <br> <br> ";

//CONCATENAM CU IMAGINILE PT SECTIUNEA "C" (MAPS & TRAINS)
dict.C[1] = dict.C[1] + CreateImageString("imgs/usualTrain.png","3/2");
dict.C[1] = dict.C[1] + "<br> > Passenger_Train_I <br> <br> ";
dict.C[1] = dict.C[1] + CreateImageString("imgs/battleTrain.png","3/2");
dict.C[1] = dict.C[1] + "<br> > Battle_Train_I <br> <br> ";

dict.C[2] = dict.C[2] + CreateImageString("imgs/bloxyCity.png","3/2");
dict.C[2] = dict.C[2] + "<br> > Bloxy City <br> <br> ";
dict.C[2] = dict.C[2] + CreateImageString("imgs/bucharest.png","3/2");
dict.C[2] = dict.C[2] + "<br> > Bucharest <br> <br> ";
//CONCATENAM CU GIF-URILE PT SECTIUNEA "F" (HOW TO PLAY)
dict.F[1] = dict.F[1] + CreateVideoString("vids/SelectDepot.mp4","3/2");
dict.F[1] = dict.F[1] + "<br> How to: > Select your BASE (train depot) <br> <br> ";
dict.F[1] = dict.F[1] + CreateVideoString("vids/CreateRails.mp4","2/1");
dict.F[1] = dict.F[1] + "<br> How to: > Create rails and connect stations <br> <br> ";
dict.F[1] = dict.F[1] + CreateVideoString("vids/CreateLine.mp4","2/1");
dict.F[1] = dict.F[1] + "<br> How to: > Create a metro line <br> <br> ";
dict.F[1] = dict.F[1] + CreateVideoString("vids/AssignTrain.mp4","2/1");
dict.F[1] = dict.F[1] + "<br> How to: > Assign train to metro line and change line color <br> <br> ";


//CONCATENAM CU IMAGINILE PT SECTIUNEA "G" (ROBLOX)
dict.G[2] = dict.G[2] + CreateImageString("imgs/pyCodeExample.png","5/2");
dict.G[2] = dict.G[2] + "<br> > Python Code Example <br><br>";
dict.G[2] = dict.G[2] + CreateImageString("imgs/luaCodeExample.png","5/2");
dict.G[2] = dict.G[2] + "<br> > Lua Code Example <br><br>";

//CONCATENAM CU IMAGINILE PT SECTIUNEA "H" (ABOUT ME)
dict.H[2] = dict.H[2] + CreateImageString("imgs/ttb.png","3/2");
dict.H[2] = dict.H[2] + "<br> > TTB - a game where you can drive trams & buses across Bucharest <br> <br> ";


let trainArrived = true

let TrainText = document.querySelector("#TrainText");


function setSquareAnim(animName) {
    for (let i = 1; i < 9; i++) {
        let sel = " #square" + i;
        let val = (0.25*i) + "s";
        const sq = document.querySelector(sel);
        sq.style.animationDelay = val;
        sq.style.animationName = animName;
    }
}

let Selector = document.querySelector("select");

window.addEventListener("DOMContentLoaded",function () {
    TrainText = document.querySelector("#TrainText");
    Selector = this.document.querySelector("select");
    Selector.addEventListener("change",function() {
        if (Selector.value=="TRAINS") {
            document.querySelector("#s1").style.display = "block";
            document.querySelector("#s2").style.display = "none";
        } else {
            document.querySelector("#s1").style.display = "none";
            document.querySelector("#s2").style.display = "block";
        }
    });
    //setam delay-urile pt animSquare
    setSquareAnim("animSquare");
})

function bringPage(obj) {
    if (trainArrived==true) {
        let elementID = obj.id;
        TrainText.innerHTML = "Going to: " + dict[elementID][0]
        document.querySelector(".trenulet").style.left = "100%";
        trainArrived = false
        setSquareAnim("animSquareTrain");
        setTimeout(   function() {
            TrainText.innerHTML = ""; 
            document.querySelector(".page").style.right = "-3%"; 
            trainArrived=true; 
        } , 1500 );
         setTimeout(   function() {
            setSquareAnim("animSquare");
        } , 2500 );
        //alert("pressed button "+elementID)
        //SETAM CONTENT-UL
        document.querySelector("#s0").innerHTML = dict[elementID][0];
        document.querySelector("#s1").innerHTML = dict[elementID][1];
        document.querySelector("#s2").innerHTML = dict[elementID][2];
        if (elementID=="C") {
            document.querySelector("#s1").style.display = "block";
            document.querySelector("#s2").style.display = "none";

            document.querySelector("select").style.display = "block";
            document.querySelector("select").value = "TRAINS";
            document.querySelectorAll("option").forEach( OPTION => {
                OPTION.style.display = "block";
            });
        } else {
            document.querySelector("#s1").style.display = "block";
            document.querySelector("#s2").style.display = "block";

            document.querySelector("select").style.display = "none";
            document.querySelectorAll("option").forEach( OPTION => {
                OPTION.style.display = "block";
            });
        }
    } else {
        TrainText.innerHTML = "Travelling..." 
        setTimeout(   function() {TrainText.innerHTML = "";} , 1000);
    }
}

function retractPage(obj) {
    if (trainArrived==true) {
        TrainText.innerHTML = "Going to: HOME PAGE" 
        const visible = document.querySelector(".page_container").checkVisibility();
        if (!visible) {
            obj.parentNode.style.right = "-100%";
            document.querySelector(".trenulet").style.left = "-45%";
        } else {
            obj.parentNode.style.right = "-65%";
            document.querySelector(".trenulet").style.left = "-25%";
        }
        trainArrived = false;
        setSquareAnim("animSquare");
        setTimeout(   function() {
            trainArrived=true; 
            TrainText.innerHTML = "";
        } , 3000);
    } else {
        TrainText.innerHTML = "Travelling..." 
        setTimeout(   function() {TrainText.innerHTML = "";} , 1000);
    }
}
