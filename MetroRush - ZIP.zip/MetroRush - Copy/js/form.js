
window.onload = function() {
    var httpRequest
    var signin = document.getElementById("signinForm")
    var login = signin.cloneNode(true)
    login.querySelector("#ForEmail").remove()
    login.id = "loginForm"
    login.method = "get"
    login.querySelector("#legend").innerHTML = "Log In with your account!"
    signin.parentNode.appendChild(login)
    signin.onsubmit = function (event){
        event.preventDefault()
        var data = {user:signin.querySelector("#name").value, 
            password:signin.querySelector("#pass").value,
            email:signin.querySelector("#email").value
        };
        const re0 = new RegExp("[A-Za-z0-9_]{1,30}")
        const re1 = new RegExp("[A-Za-z0-9.@]{1,45}")
        if (re0.test(data.user) && re1.test(data.email)) {
            httpRequest = new XMLHttpRequest()
            if (!httpRequest) {
                alert('problem!')
                return false;
            }
            httpRequest.onreadystatechange = function() {
                alertContents(data)
            }
            httpRequest.open('POST', signin.action, true)
            httpRequest.setRequestHeader("Content-Type", "application/json")
            httpRequest.send(JSON.stringify(data))
        } else {
            alert('Please insert valid details')
        }
    }
    login.onsubmit = function(event) {
        event.preventDefault()
        const username = login.querySelector("#name").value
        const password = login.querySelector("#pass").value
        fetch("js/data.json")
        .then(res => res.json())
        .then(users => {
            if (!users[username]) {
                alert("User not found")
                return;
        }
            if (users[username].password === password) {
                alert("Login successful!")
                console.log(users[username])
                document.getElementById("loginUserText").innerHTML = "Logged in as "+username
                login.style.display = "none"
            } else {
                alert("Wrong password")
            }
        })
        .catch(err => console.error("Error: ", err))
    }
    function alertContents(data) {
        if (httpRequest.readyState == 4) {
            if (httpRequest.status == 200) {
                alert('Succesfully signed in!')
                document.getElementById("loginUserText").innerHTML = "Logged in as "+data.user
            } else {
                alert('Encountered a problem!')
            }
        }
    }
}

function loginPrompt() {
    var form = document.getElementById("FormContainer");
    form.style.display = "block"
    var signin = document.getElementById("signinForm");
    signin.style.display = "none"
    var login = document.getElementById("loginForm");
    login.style.display = "block"
}

function signInPrompt() {
    var form = document.getElementById("FormContainer");
    form.style.display = "block"
    var signin = document.getElementById("signinForm");
    signin.style.display = "block"
    var login = document.getElementById("loginForm");
    login.style.display = "none"
}

function deactivateForm() {
    var form = document.getElementById("FormContainer");
    form.style.display = "none"
    var signin = document.getElementById("signinForm");
    signin.style.display = "none"
    var login = document.getElementById("loginForm");
    login.style.display = "none"
}